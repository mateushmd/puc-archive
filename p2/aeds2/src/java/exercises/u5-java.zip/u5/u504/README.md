a) Dada uma matriz, crie uma lista simples para cada linha com os itens invertidos, e retorne uma lista delas
b) A partir da lista de lista, faça uma árvore intercalando as listas  